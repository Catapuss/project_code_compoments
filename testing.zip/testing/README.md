# project_code_compoments
purpose: store project code and components
